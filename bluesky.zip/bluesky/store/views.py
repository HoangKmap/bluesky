from django.shortcuts import render, redirect
from django.http import JsonResponse
import json
import datetime
from django.db.models.signals import pre_save
from django.contrib.auth import login as auth_login, authenticate, logout as auth_logout
from django.core.paginator import Paginator
from .models import *
from .utils import cookieCart, guestOrder
from .forms import LoginForm, RegisterForm

#create a function that will update the quantity of the product when an order item is created
def store(request):
    data = cookieCart(request)

    cart_data = data

    products = Product.objects.all()
    page_number = request.GET.get('page') or 1
    page_obj = Paginator(products, 8).get_page(page_number)
    print(page_obj.paginator.num_pages)
    context = {'page_data': page_obj, 'cart': cart_data, 'page_range': range(1, page_obj.paginator.num_pages + 1), 'current_page': int(page_number)}
    return render(request, 'store/store.html', context)

def cart(request):
    data = cookieCart(request)
    cartItems = data['cartItems']
    order = data['order']
    items = data['items']

    context = {'items': items, 'order': order, 'cartItems': cartItems}
    return render(request, 'store/cart.html', context)
#-----------------------------------------------------------------------------
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def search_ordered(request):
    if request.method == 'POST':
        jitems = []
        nItems = 0 
        context = {'items': {}, 'cart_items': 0, 'cart_total': 0}
        total = 0
        try:
            data = json.loads(request.body)
            orderid = data['form']['order']
            shippingAddress = ShippingAddress.objects.get(order=orderid)
            client = Client.objects.get(order =orderid)

            orderid = Order.objects.get(id =orderid)
            
            print("orderid: ",client.name, client.email, shippingAddress)
            shipping = {'customer': {'name': client.name, 'email': client.email}, 
                        'shippingAddress': {'adress': shippingAddress.address, 'city': shippingAddress.city, 'state': shippingAddress.state,
                                            'zipcode': shippingAddress.zipcode, 'date_added': shippingAddress.date_added.strftime('%F')}}
            items = OrderItem.objects.filter(order=orderid)
            # perform search logic
            for item in items:
                produce = item.product.name
                quantity = item.quantity
                price = item.get_total
                imageURL = item.product.imageURL
                j_item = {'product': {'name': produce, 'price': price, 'imageURL': imageURL}, 'quantity': quantity}
                jitems.append(j_item)
            total = sum([item['product']['price'] * item['quantity'] for item in jitems])
            nItems = len(jitems)
            context = {'items': jitems, 'cart_items': nItems, 'cart_total': total, 'shipping': shipping}
            #print("context: ", context)
            return JsonResponse(context) # send JSON response
        except json.decoder.JSONDecodeError:
            render(request, 'store/ordered.html')
        except Order.DoesNotExist:
            print("context is empty")
            return render(request, 'store/ordered.html',context)
    return render(request, 'store/ordered.html')
#-------------------------------------------------------------------------------
def checkout(request):
    data = cookieCart(request)
    return render(request, 'store/checkout.html', {'cart': data})

@csrf_exempt
def updateCart(request):
    data = json.loads(request.body)
    cart = cookieCart(request)['items']

    if data['action'] == 'REMOVE':
        cart = [item for item in cart if item['id'] != data['productId']]
    elif data['productId'] not in list(map(lambda item: item['id'], cart)):
        cart.append({
            'id': data['productId'],
            'quantity': 1
        })
    else:
        index = [i for i in range(len(cart)) if cart[i]['id'] == data['productId']][0]
        if data['action'] == 'ADD':
            cart[index]['quantity'] += 1
        else:
            cart[index]['quantity'] = data['quantity']

    print(cart)

    request.COOKIES['cart'] = json.dumps(cart)

    cart_data = cookieCart(request)
    print(cart_data)

    return JsonResponse(cart_data, safe=False)

def processOrder(request):
    transaction_id = datetime.datetime.now().timestamp()
    data = json.loads(request.body)

    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(customer=customer, complete=False)
    else:
        customer, order = guestOrder(request, data)

    total = float(data['form']['total'])
    order.transaction_id = transaction_id

    if total == order.get_cart_total:
        order.complete = True
    order.save()

    if order.shipping == True:
        ShippingAddress.objects.create(
            customer=customer,
            order=order,
            address=data['shipping']['address'],
            city=data['shipping']['city'],
            state=data['shipping']['state'],
            zipcode=data['shipping']['zipcode'],
        )

        Client.objects.create(
            customer=customer,
            order=order,
            name=data['client']['name'],
            email=data['client']['email'],
        )
    
    return JsonResponse('Payment submitted..', safe=False)

def login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)

        if not form.is_valid():
            return render(request, 'store/login.html', {'form': form})

        user = authenticate(username=form.cleaned_data['username'], password=form.cleaned_data['password'])

        if user is not None:
            auth_login(request, user)
            return redirect('/' if user.is_superuser == 0 else '/admin')
        else:
            form.add_error('username', 'Tên đăng nhập hoặc mật khẩu không chính xác')
            return render(request, 'store/login.html', {'form': form})
    return render(request, 'store/login.html', {'form': LoginForm()})

def signUp(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)

        if not form.is_valid():
            return render(request, 'store/register.html', {'form': form})

        user = authenticate(username = form.cleaned_data['username'], password = form.cleaned_data['password'])

        if user is not None:
            form.add_error('username', 'Tên đăng nhập đã được sử dụng')
            return render(request, 'store/register.html', {'form': form})
        
        user = User(username = form.cleaned_data['username'], is_staff=1)
        user.set_password(form.cleaned_data['password'])

        user.save()
        Customer.objects.create(user=user, name=user.username)
        return redirect('/login')
    return render(request, 'store/register.html', {'form': RegisterForm()})

def logout(request):
    if request.method == 'POST':
        auth_logout(request)
        return redirect('/login')